#ifndef UTIL_LINUX_PAGER
#define UTIL_LINUX_PAGER

void pager_redirect(void);

void pager_open(void);
void pager_close(void);

#endif
